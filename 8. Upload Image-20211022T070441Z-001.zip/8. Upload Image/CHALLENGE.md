# Challenge
Hi Troops !
We have a new web application that allow every camp to upload their activities.
Could you find any vulnerabilities?

