<?php
define('CLIENT_SESSION_ID', 'session');
define('SECRET_KEY', getenv('SECRET_KEY'));
define('UPLOAD_DIR', __DIR__ . '/uploads');