# Solution

# Flag
CYDEF{L3arn_LFI_1nj3ction}